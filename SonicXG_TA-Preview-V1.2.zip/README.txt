Sonic XG Time Attack Preview - v1.2 2026/08/02

OS: Microsoft 64bit Windows 10
Processor: 64bit Intel compatible Dual Core CPU
Memory: 2 GB RAM
Graphics: OpenGL 4-compliant onboard graphics
DirectX: Version 11
Storage: 35-50MB
-----------------------------------

Thanks for trying out the Time Attack preview for Sonic XG (Project Forever)!

For valuable starting information, it's greatly recommended you visit the website and check out the online manual.

Sonic-XG.github.io

With that being said, go on and have a blast running through Final Fall!

-----------------------------------
Further technical info regarding Time Attack files:

Replay and sync files are located within your local appdata folder.

It should be noted that input recording/playback is prone to rare floating point number errors. 
If this happens, the game will attempt to resync the player and continue playback with the help of the replay's .sync file.
If one is attempting to share replays, it is recommended (but not required beyond serving as a playback sync failsafe) to also send the .sync file with a matching name.

!!!IMPORTANT!!! The specific (default) directory where these files are stored on Windows might look something like this:
[C:\Users\(user)\AppData\Local\Sonic_XG]  
To easily access Appdata, hit WindowsKey+R, and type %appdata% in the box. From there, navigate back a folder to find the "Local" folder.
Click on "Local" and scroll down until you see Sonic_XG. You should now be able to see the files mentioned here!

'uuid.bin' is the file responsible for ownership of your best times and replays. Don't lose it!

'options.txt' is where player inputs/options are stored. (NOT TO BE CONFUSED with Gamemaker's mandatory 'options.ini' file in this executable directory)

F4 and F12 keys also serve as quick resolution and border toggles respectively.
-----------------------------------

For more info, make sure to check out the online manual included in the link above.

Have feedback? Feel free to tell us about it in the Ultra Ring Community server on Discord! (Link located on the site as well!)